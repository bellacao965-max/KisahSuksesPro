/*
Enhanced secure AI proxy server
---------------------------------
Features:
✅ CORS with allowed origin (ALLOWED_ORIGIN env)
✅ Dual Auth: Basic Auth OR x-api-key header (API_KEY env)
✅ Rate limiting (express-rate-limit)
✅ Input validation and error handling
✅ Ready for Docker and systemd deployment

Environment Variables:
  OPENAI_API_KEY  -> your OpenAI API key (required)
  BASIC_AUTH_USER -> username for basic auth (optional if API_KEY used)
  BASIC_AUTH_PASS -> password for basic auth (optional if API_KEY used)
  API_KEY         -> secret token to authenticate via 'x-api-key' header
  ALLOWED_ORIGIN  -> CORS allowed origin (e.g., http://localhost:5173)
  PORT            -> server port (default: 3000)

Run:
  npm install
  export OPENAI_API_KEY="sk-..."
  export BASIC_AUTH_USER="admin"
  export BASIC_AUTH_PASS="s3cret"
  export API_KEY="supersecretkey123"
  node server.js
*/

const express = require('express');
require('dotenv').config();
const fetch = require('node-fetch');
const rateLimit = require('express-rate-limit');
const basicAuth = require('express-basic-auth');
const cors = require('cors');

const app = express();
app.use(express.json({ limit: '1mb' }));

// === CORS ===
const allowedOrigin = process.env.ALLOWED_ORIGIN || '*';
app.use(cors({ origin: allowedOrigin }));

// === Auth middlewares ===
const useBasicAuth = process.env.BASIC_AUTH_USER && process.env.BASIC_AUTH_PASS;
const apiKey = process.env.API_KEY;

function dualAuth(req, res, next) {
  // Allow x-api-key authentication
  if (apiKey && req.headers['x-api-key'] === apiKey) return next();
  // Otherwise fall back to basic auth if available
  if (useBasicAuth) return basicAuth({
    users: { [process.env.BASIC_AUTH_USER]: process.env.BASIC_AUTH_PASS },
    challenge: true,
    unauthorizedResponse: { error: 'Unauthorized' }
  })(req, res, next);
  return res.status(401).json({ error: 'Unauthorized - No valid auth method' });
}

// === Rate limiter ===
const aiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  message: { error: 'Too many requests, please try again later.' }
});

// === AI Proxy Endpoint ===
app.post('/api/ai', dualAuth, aiLimiter, async (req, res) => {
  const prompt = req.body.prompt || '';
  if (!process.env.OPENAI_API_KEY) {
    return res.status(500).json({ error: 'Server misconfigured: OPENAI_API_KEY missing' });
  }
  if (!prompt || typeof prompt !== 'string' || prompt.length > 5000) {
    return res.status(400).json({ error: 'Invalid prompt' });
  }
  try {
    const response = await fetch('https://api.openai.com/v1/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + process.env.OPENAI_API_KEY
      },
      body: JSON.stringify({
        model: 'text-davinci-003',
        prompt,
        max_tokens: req.body.max_tokens || 400
      })
    });
    const data = await response.json();
    res.json(data);
  } catch (err) {
    console.error('Proxy error:', err);
    res.status(500).json({ error: 'AI proxy error' });
  }
});


// === Streaming SSE endpoint (simulated) ===
// POST /api/ai/stream expects same body as /api/ai. It will fetch the full response and stream it in chunks via Server-Sent Events (SSE).
app.post('/api/ai/stream', dualAuth, aiLimiter, async (req, res) => {
  const prompt = req.body.prompt || '';
  if (!process.env.OPENAI_API_KEY) return res.status(500).json({ error: 'Server misconfigured: OPENAI_API_KEY missing' });
  if (!prompt || typeof prompt !== 'string' || prompt.length > 5000) return res.status(400).json({ error: 'Invalid prompt' });

  try {
    // Fetch full completion from OpenAI (non-streaming), then stream chunks to client via SSE.
    const response = await fetch('https://api.openai.com/v1/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + process.env.OPENAI_API_KEY },
      body: JSON.stringify({ model: 'text-davinci-003', prompt, max_tokens: req.body.max_tokens || 400 })
    });
    const data = await response.json();
    let text = '';
    if (data && data.choices && data.choices[0] && data.choices[0].text) text = data.choices[0].text;
    else text = JSON.stringify(data);

    // Send SSE headers
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': process.env.ALLOWED_ORIGIN || '*'
    });

    // Stream by chunks (words)
    const words = text.split(/(\s+)/);
    for (let i = 0; i < words.length; i++) {
      res.write('data: ' + words[i] + '\n\n');
      await new Promise(r => setTimeout(r, 30)); // small delay to simulate streaming
    }
    res.write('event: done\ndata: [DONE]\n\n');
    res.end();
  } catch (err) {
    console.error('Streaming proxy error:', err);
    return res.status(500).json({ error: 'AI streaming proxy error' });
  }
});


// === Health check ===
app.get('/health', (req, res) => res.json({ ok: true }));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`✅ AI proxy server running at http://localhost:${port}`));
