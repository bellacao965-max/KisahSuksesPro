/*
 ai.js - Enhanced AI integration
 - askAI(prompt, opts) -> calls /api/ai by default
 - helper functions: summarizeText(text), analyzeCode(code), suggestDesign(notes)
*/
async function askAI(prompt, opts = {}) {
  const body = { prompt, max_tokens: opts.max_tokens || 400, temperature: opts.temperature || 0.6 };
  // Try proxy
  try {
    const resp = await fetch('/api/ai', { method: 'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
    if (resp.ok) {
      const j = await resp.json();
      if (j.text) return j.text;
      if (j.choices && j.choices[0] && j.choices[0].text) return j.choices[0].text;
      return JSON.stringify(j);
    }
  } catch (e) {
    console.debug('AI proxy unavailable', e);
  }
  // Fallback to direct OpenAI only if key present (not recommended)
  if (window.OPENAI_API_KEY) {
    const resp = await fetch('https://api.openai.com/v1/completions', {
      method:'POST',
      headers:{'Content-Type':'application/json','Authorization':'Bearer '+window.OPENAI_API_KEY},
      body: JSON.stringify({ model:'text-davinci-003', prompt, max_tokens: body.max_tokens, temperature: body.temperature })
    });
    const j = await resp.json();
    if (j.choices && j.choices[0]) return j.choices[0].text;
    return JSON.stringify(j);
  }
  throw new Error('No AI backend available.');
}

function promptSummarize(text) {
  return `Ringkaskan teks berikut menjadi 5 poin utama, gunakan bahasa Indonesia:\n\n${text}`;
}
function promptAnalyzeCode(code) {
  return `Analisis kode berikut untuk bug, antipattern, dan peluang optimasi. Tulis laporan terstruktur dengan rekomendasi langkah perbaikan (bahasa Indonesia):\n\n${code}`;
}
function promptSuggestDesign(notes) {
  return `Berikan saran desain UI/UX berbasis catatan berikut. Sebutkan masalah, solusi, dan contoh interaksi singkat (bahasa Indonesia):\n\n${notes}`;
}

async function summarizeText(text) { return askAI(promptSummarize(text), {max_tokens:300}); }
async function analyzeCode(code) { return askAI(promptAnalyzeCode(code), {max_tokens:500}); }
async function suggestDesign(notes) { return askAI(promptSuggestDesign(notes), {max_tokens:350}); }

function appendChatMessage(container, who, text) {
  const div = document.createElement('div');
  div.className = 'chat-message ' + (who === 'user' ? 'user' : 'ai');
  div.innerText = (who === 'user' ? 'You: ' : 'AI: ') + text;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}
window.ai = { askAI, summarizeText, analyzeCode, suggestDesign, appendChatMessage };


// Streaming helper using EventSource or fetch + text/event-stream
async function askAIStream(prompt, onChunk, opts = {}) {
  // Try server streaming endpoint first
  const url = '/api/ai/stream';
  try {
    const evtSource = new EventSourcePolyfill(url, { // polyfill provided by tiny-event-source if needed
      headers: { 'Content-Type': 'application/json' },
      method: 'POST',
      body: JSON.stringify({ prompt, max_tokens: opts.max_tokens || 400 })
    });
  } catch (e) {
    // Fallback: use fetch to get full text then call onChunk with chunks
    const full = await askAI(prompt, opts);
    // split into chunks approx 60 chars
    const parts = full.match(/.{1,60}/g) || [full];
    for (const p of parts) { onChunk(p); await new Promise(r=>setTimeout(r,30)); }
    return;
  }
}

// Note: browsers don't support EventSource POST natively. The server provides /api/ai/stream SSE and this helper falls back to simulated streaming.

