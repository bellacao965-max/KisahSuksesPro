const { app, BrowserWindow } = require('electron');
const path = require('path');
const { spawn } = require('child_process');

let serverProcess = null;

function startServer() {
  const serverPath = path.join(__dirname, '..', 'server', 'server.js');
  serverProcess = spawn(process.execPath, [serverPath], {
    env: Object.assign({}, process.env),
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  serverProcess.stdout && serverProcess.stdout.on('data', (d) => {
    console.log('[server]', d.toString());
  });
  serverProcess.stderr && serverProcess.stderr.on('data', (d) => {
    console.error('[server]', d.toString());
  });
  serverProcess.on('exit', (code) => {
    console.log('Server exited with', code);
  });
}

function stopServer() {
  if (serverProcess && !serverProcess.killed) {
    serverProcess.kill();
    serverProcess = null;
  }
}

function createWindow () {
  const win = new BrowserWindow({
    width: 1100,
    height: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    }
  });

  // load local index.html
  const indexPath = path.join(__dirname, '..', 'index.html');
  win.loadFile(indexPath);
  // Optional: open devtools in dev
  // win.webContents.openDevTools();
}

app.whenReady().then(() => {
  startServer();
  createWindow();

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('before-quit', () => {
  stopServer();
});

app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') {
    stopServer();
    app.quit();
  }
});
